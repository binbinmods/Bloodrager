# 0.2.4

Slasher gives damage instead of resists.

# 0.2.3

Tear no longer adds vanish.

# 0.2.2

Bleed now increases damage properly

# 0.2.1

Fixed issue with incorrect SubclassName causing issues

# 0.2.0

Initial pre-release for play testing

# 0.1.2

Fixed Sharp increasing bleed from increasing every time you look at the combat sheet.

Reworked some traits

# 0.1.1

Fixed a bug where enemies could dispel their bleed when Rip is active.

Fixed a bug with trait2a not doubling vitality health

Changed Tear to proc on attack rather than any card

# 0.1.0

Initial concenpt