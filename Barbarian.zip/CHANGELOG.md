# 0.1.1

Fixed a bug where enemies could dispel their bleed when Rip is active.

# 0.1.0

Initial pre-release